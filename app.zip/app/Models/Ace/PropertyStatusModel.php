<?php

namespace App\Models\ace;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PropertyStatusModel extends Model
{
    use HasFactory;
    public $table = 'propertystatusnames';
}
