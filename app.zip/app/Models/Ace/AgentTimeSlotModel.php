<?php

namespace App\Models\Ace;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AgentTimeSlotModel extends Model
{
    use HasFactory;
    public $table = 'agenttimeslots';
}
